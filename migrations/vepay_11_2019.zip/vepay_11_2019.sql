/*
SQLyog Ultimate v12.09 (32 bit)
MySQL - 5.5.56-log : Database - vepay
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `act_bank` */

DROP TABLE IF EXISTS `act_bank`;

CREATE TABLE `act_bank` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ActPeriod` int(10) unsigned NOT NULL,
  `DateCreate` int(10) unsigned NOT NULL,
  `FileName` varchar(250) NOT NULL,
  `SumOCT` int(11) NOT NULL,
  `SumPerevod` int(11) NOT NULL,
  `SumPaysJkh` int(11) NOT NULL,
  `SumPaysEcom` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ActPeriod` (`ActPeriod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `act_bank` */

LOCK TABLES `act_bank` WRITE;

UNLOCK TABLES;

/*Table structure for table `act_mfo` */

DROP TABLE IF EXISTS `act_mfo`;

CREATE TABLE `act_mfo` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPartner` int(10) unsigned NOT NULL COMMENT 'id partner mfo',
  `NumAct` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'nomer acta',
  `ActPeriod` int(10) unsigned NOT NULL COMMENT 'period unixts',
  `CntPerevod` int(10) unsigned NOT NULL COMMENT 'chislo perevodov',
  `SumPerevod` int(10) unsigned NOT NULL COMMENT 'summa perevodov',
  `ComisPerevod` int(10) unsigned NOT NULL COMMENT 'komissia banka',
  `DateCreate` int(10) unsigned NOT NULL COMMENT 'data formirovania',
  `FileName` varchar(250) DEFAULT NULL COMMENT 'fail',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IdPartner` (`IdPartner`,`ActPeriod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `act_mfo` */

LOCK TABLES `act_mfo` WRITE;

UNLOCK TABLES;

/*Table structure for table `banks` */

DROP TABLE IF EXISTS `banks`;

CREATE TABLE `banks` (
  `ID` int(10) unsigned NOT NULL,
  `Name` varchar(250) NOT NULL,
  `JkhComis` double NOT NULL DEFAULT '0',
  `JkhComisMin` double NOT NULL DEFAULT '0',
  `EcomComis` double NOT NULL DEFAULT '0',
  `EcomComisMin` double NOT NULL DEFAULT '0',
  `AFTComis` double NOT NULL DEFAULT '0',
  `AFTComisMin` double NOT NULL DEFAULT '0',
  `OCTComis` double NOT NULL DEFAULT '0',
  `OCTComisMin` double NOT NULL DEFAULT '0',
  `FreepayComis` double NOT NULL DEFAULT '0',
  `FreepayComisMin` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `banks` */

LOCK TABLES `banks` WRITE;

insert  into `banks`(`ID`,`Name`,`JkhComis`,`JkhComisMin`,`EcomComis`,`EcomComisMin`,`AFTComis`,`AFTComisMin`,`OCTComis`,`OCTComisMin`,`FreepayComis`,`FreepayComisMin`) values (0,'РСБ',0.8,0,0,0,0,0,0,0,0,0),(1,'Россия',0.7,0,0,0,0,0,0,0,0,0),(2,'ТКБ',0.75,0,2,0,0.7,40,0.35,40,0.3,30);

UNLOCK TABLES;

/*Table structure for table `cardactivate` */

DROP TABLE IF EXISTS `cardactivate`;

CREATE TABLE `cardactivate` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - full 1 - simple',
  `ExtId` varchar(50) DEFAULT NULL,
  `Org` int(10) unsigned NOT NULL,
  `CardNum` varchar(20) NOT NULL,
  `ControlWord` varchar(30) NOT NULL,
  `IdClientInfo` int(10) unsigned NOT NULL DEFAULT '0',
  `IdTrancact` int(10) unsigned NOT NULL DEFAULT '0',
  `DateAdd` int(10) unsigned NOT NULL DEFAULT '0',
  `DateActivate` int(10) unsigned NOT NULL DEFAULT '0',
  `State` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - in process 1 - ok 2 - error',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cardactivate` */

LOCK TABLES `cardactivate` WRITE;

UNLOCK TABLES;

/*Table structure for table `cards` */

DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `NameCard` varchar(150) DEFAULT NULL COMMENT 'naimenovanie karty',
  `ExtCardIDP` varchar(150) DEFAULT NULL COMMENT 'vneshniii id karty 128 chisel',
  `CardNumber` varchar(40) DEFAULT NULL COMMENT 'nomer karty',
  `CardType` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip karty: 0 - visa, 1 - mastercard',
  `SrokKard` int(4) unsigned NOT NULL DEFAULT '0' COMMENT 'srok deistvia karty - MMYY',
  `Status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'status karty: 0 - ne podtvejdena 1 - aktivna 2 - zablokirovana',
  `CheckSumm` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa dlia proverki privyazki',
  `DateAdd` int(10) unsigned NOT NULL COMMENT 'data dobavlenia',
  `Default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'po umolchaniu',
  `TypeCard` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - dlia oplaty 1 - dlia popolnenia',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - activna 1 - udalena',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cards` */

LOCK TABLES `cards` WRITE;

UNLOCK TABLES;

/*Table structure for table `drafts` */

DROP TABLE IF EXISTS `drafts`;

CREATE TABLE `drafts` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPaySchet` int(10) unsigned DEFAULT NULL COMMENT 'id pay_schet',
  `Urlico` varchar(200) DEFAULT NULL COMMENT 'ur lico',
  `Inn` varchar(20) DEFAULT NULL COMMENT 'inn',
  `Sno` varchar(20) DEFAULT NULL COMMENT 'sistema nalogooblajenia',
  `NumDocument` varchar(20) DEFAULT NULL COMMENT 'dokument',
  `NumDraft` varchar(20) DEFAULT NULL COMMENT 'check',
  `Smena` varchar(20) DEFAULT NULL COMMENT 'smena',
  `DateDraft` varchar(20) DEFAULT NULL COMMENT 'data i vremia cheka',
  `FDNumber` varchar(20) DEFAULT NULL COMMENT 'fd',
  `FPCode` varchar(20) DEFAULT NULL COMMENT 'fp',
  `KassaRegNumber` varchar(20) DEFAULT NULL COMMENT 'rn',
  `KassaSerialNumber` varchar(20) DEFAULT NULL COMMENT 'zn',
  `FNSerialNumber` varchar(20) DEFAULT NULL COMMENT 'fn',
  `Tovar` varchar(400) DEFAULT NULL COMMENT 'tovar',
  `Summ` int(10) unsigned DEFAULT '0' COMMENT 'summa',
  `SummNoNds` int(10) unsigned DEFAULT '0' COMMENT 'summa bez nds',
  `Email` varchar(50) DEFAULT NULL COMMENT 'email klienta',
  PRIMARY KEY (`ID`),
  KEY `IdPaySchet` (`IdPaySchet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `drafts` */

LOCK TABLES `drafts` WRITE;

UNLOCK TABLES;

/*Table structure for table `export_pay` */

DROP TABLE IF EXISTS `export_pay`;

CREATE TABLE `export_pay` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdSchet` int(10) unsigned NOT NULL COMMENT 'id pay_schet',
  `DateExport` int(10) unsigned NOT NULL COMMENT 'data eksporta',
  `Transaction` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id tranzakcii plateja',
  `IdReestrBankplat` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id systemdorod.reestr_bankplat',
  `DateSendEmail` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otpavki uvedomlenia po email',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IdSchet` (`IdSchet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `export_pay` */

LOCK TABLES `export_pay` WRITE;

UNLOCK TABLES;

/*Table structure for table `help` */

DROP TABLE IF EXISTS `help`;

CREATE TABLE `help` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `Message` text NOT NULL COMMENT 'soobshenie',
  `Direct` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - vopros 1 - otvet',
  `DateMesg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`,`Direct`,`IsDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `help` */

LOCK TABLES `help` WRITE;

UNLOCK TABLES;

/*Table structure for table `history` */

DROP TABLE IF EXISTS `history`;

CREATE TABLE `history` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'istoria shtrihkodov',
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `Type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 - oplata kuponom 1 - oplata jkh 2 - bilet 3 - oplata po qr kody',
  `IdOperation` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id operacii dlia tipa 0 - qr_oplatauslugi 1 - reestr_schet 2 - id bilet_oplata 3 - id pay_schet',
  `InfoHead` varchar(100) DEFAULT NULL COMMENT 'info 1',
  `InfoText` varchar(100) DEFAULT NULL COMMENT 'info 2',
  `DateAdd` int(10) unsigned NOT NULL COMMENT 'data',
  `Summa` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `history` */

LOCK TABLES `history` WRITE;

UNLOCK TABLES;

/*Table structure for table `kf_investor` */

DROP TABLE IF EXISTS `kf_investor`;

CREATE TABLE `kf_investor` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdOrg` int(10) NOT NULL DEFAULT '0',
  `IdUser` int(10) unsigned NOT NULL DEFAULT '0',
  `Balance` bigint(10) NOT NULL DEFAULT '0',
  `Type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - investor 1 - zayiomshik',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `kf_investor` */

LOCK TABLES `kf_investor` WRITE;

UNLOCK TABLES;

/*Table structure for table `kf_orders` */

DROP TABLE IF EXISTS `kf_orders`;

CREATE TABLE `kf_orders` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdInvestor` int(10) unsigned NOT NULL,
  `DateOp` int(10) unsigned NOT NULL,
  `SummOp` bigint(20) NOT NULL,
  `SummAfter` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `kf_orders` */

LOCK TABLES `kf_orders` WRITE;

UNLOCK TABLES;

/*Table structure for table `notification_pay` */

DROP TABLE IF EXISTS `notification_pay`;

CREATE TABLE `notification_pay` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPay` int(10) unsigned NOT NULL COMMENT 'id pay_schet',
  `Email` varchar(1000) DEFAULT NULL COMMENT 'to email or url',
  `TypeNotif` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - dlia polzovatelia 1 - dlia magazina',
  `DateCreate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data sozdania',
  `DateSend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otparavki uvedomlenia',
  PRIMARY KEY (`ID`),
  KEY `IdPay` (`IdPay`,`DateSend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `notification_pay` */

LOCK TABLES `notification_pay` WRITE;

UNLOCK TABLES;

/*Table structure for table `oplatatakze` */

DROP TABLE IF EXISTS `oplatatakze`;

CREATE TABLE `oplatatakze` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FromUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `FromOrg` int(10) NOT NULL DEFAULT '0' COMMENT 'id uslugatovar',
  `FromLs` varchar(100) NOT NULL DEFAULT '' COMMENT 'shablon acount',
  `IdShablon` int(10) unsigned NOT NULL COMMENT 'shanlon',
  `Period` int(10) unsigned NOT NULL COMMENT 'period',
  `DateShown` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otobrajenia',
  PRIMARY KEY (`ID`),
  KEY `FromOrg` (`FromOrg`,`FromLs`),
  KEY `FromUser` (`FromUser`),
  KEY `Period` (`Period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `oplatatakze` */

LOCK TABLES `oplatatakze` WRITE;

UNLOCK TABLES;

/*Table structure for table `order_notif` */

DROP TABLE IF EXISTS `order_notif`;

CREATE TABLE `order_notif` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdOrder` int(10) unsigned NOT NULL COMMENT 'id order_pay',
  `DateAdd` int(10) unsigned NOT NULL COMMENT 'data sozdania',
  `DateSended` int(10) unsigned NOT NULL COMMENT 'data otpravki',
  `TypeSend` tinyint(1) unsigned NOT NULL COMMENT 'tip otpravki - 0 - email 1 - sms',
  `StateSend` tinyint(1) unsigned NOT NULL COMMENT 'status otravki: 0 - v ocheredi 1 - uspeshno 2 - oshibka',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `order_notif` */

LOCK TABLES `order_notif` WRITE;

UNLOCK TABLES;

/*Table structure for table `order_pay` */

DROP TABLE IF EXISTS `order_pay`;

CREATE TABLE `order_pay` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPartner` int(10) unsigned NOT NULL COMMENT 'id partner',
  `DateAdd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data vystavlenia',
  `DateEnd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data okonchania deistvia scheta',
  `DateOplata` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data oplaty',
  `SumOrder` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa scheta',
  `Comment` text COMMENT 'komentarii',
  `EmailTo` varchar(50) DEFAULT NULL COMMENT 'nomer dlia email',
  `EmailSended` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otpravki email',
  `SmsTo` varchar(50) DEFAULT NULL COMMENT 'nomer dlia sms',
  `SmsSended` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otpravki sms',
  `StateOrder` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'status - 0 - ojidaet 1 - oplachen 2 - otshibka',
  `IdPaySchet` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id pay_schet',
  `IdDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdPartner` (`IdPartner`,`DateAdd`,`StateOrder`,`IdDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `order_pay` */

LOCK TABLES `order_pay` WRITE;

UNLOCK TABLES;

/*Table structure for table `part_user_access` */

DROP TABLE IF EXISTS `part_user_access`;

CREATE TABLE `part_user_access` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL,
  `IdRazdel` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`,`IdRazdel`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

/*Data for the table `part_user_access` */

LOCK TABLES `part_user_access` WRITE;

insert  into `part_user_access`(`ID`,`IdUser`,`IdRazdel`) values (19,2,0),(20,2,1),(21,2,2),(22,2,3),(23,3,0),(24,3,1),(25,3,2),(26,3,3);

UNLOCK TABLES;

/*Table structure for table `partner` */

DROP TABLE IF EXISTS `partner`;

CREATE TABLE `partner` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'partnery',
  `Name` varchar(250) DEFAULT NULL COMMENT 'naimenovanie v sisteme',
  `UrLico` varchar(250) DEFAULT NULL,
  `INN` varchar(20) DEFAULT NULL,
  `KPP` varchar(20) DEFAULT NULL,
  `OGRN` varchar(20) DEFAULT NULL,
  `UrAdres` varchar(1000) DEFAULT NULL COMMENT 'uridicheskii adres - index|oblast|raion|gorod|ylica|dom|ofis',
  `PostAdres` varchar(1000) DEFAULT NULL COMMENT 'pochtovyii adres - index|oblast|raion|gorod|ylica|dom|ofis',
  `DateRegister` int(10) unsigned NOT NULL COMMENT 'data registracii',
  `NumDogovor` varchar(20) DEFAULT NULL,
  `DateDogovor` varchar(20) DEFAULT NULL,
  `PodpisantFull` varchar(100) DEFAULT NULL COMMENT 'podpisant',
  `PodpisantShort` varchar(50) DEFAULT NULL COMMENT '-',
  `PodpDoljpost` varchar(100) DEFAULT NULL COMMENT '-',
  `PodpDoljpostRod` varchar(100) DEFAULT NULL COMMENT '-',
  `PodpOsnovan` varchar(100) DEFAULT NULL COMMENT '-',
  `PodpOsnovanRod` varchar(100) DEFAULT NULL COMMENT '-',
  `URLSite` varchar(200) DEFAULT NULL COMMENT 'sait',
  `Phone` varchar(50) DEFAULT NULL COMMENT 'telefon',
  `Email` varchar(50) DEFAULT NULL COMMENT 'pochta',
  `KontTehFio` varchar(100) DEFAULT NULL COMMENT 'fio po teh voporosam',
  `KontTehEmail` varchar(50) DEFAULT NULL COMMENT 'email po teh voporosam',
  `KontTehPhone` varchar(50) DEFAULT NULL COMMENT 'phone po teh voporosam',
  `KontFinansFio` varchar(100) DEFAULT NULL COMMENT 'fio po finansovym voporosam',
  `KontFinansEmail` varchar(50) DEFAULT NULL COMMENT 'email po finansovym voporosam',
  `KontFinansPhone` varchar(50) DEFAULT NULL COMMENT 'email po finansovym voporosam',
  `RSchet` varchar(50) DEFAULT NULL COMMENT 'raschethyii schet',
  `KSchet` varchar(50) DEFAULT NULL COMMENT 'kor schet',
  `BankName` varchar(100) DEFAULT NULL COMMENT 'bank naimenovanie',
  `BikBank` varchar(20) DEFAULT NULL COMMENT 'bik banka',
  `PaaswordApi` varchar(50) DEFAULT NULL COMMENT 'parol api mfo',
  `IpAccesApi` varchar(300) DEFAULT NULL COMMENT 'ogranichenie po IP adresu',
  `IsMfo` tinyint(1) DEFAULT '0' COMMENT '1 - mfo',
  `SchetTcb` varchar(40) DEFAULT NULL COMMENT 'r.schet tcb',
  `LoginTkbAft` varchar(40) DEFAULT NULL COMMENT 'tck terminal atf oct',
  `KeyTkbAft` varchar(300) DEFAULT NULL,
  `LoginTkbEcom` varchar(40) DEFAULT NULL COMMENT 'tck terminal ecom',
  `KeyTkbEcom` varchar(300) DEFAULT NULL,
  `IsBlocked` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - aktiven 1 - zablokirovan',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - rabotaet 1 - udalen',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `partner` */

LOCK TABLES `partner` WRITE;

insert  into `partner`(`ID`,`Name`,`UrLico`,`INN`,`KPP`,`OGRN`,`UrAdres`,`PostAdres`,`DateRegister`,`NumDogovor`,`DateDogovor`,`PodpisantFull`,`PodpisantShort`,`PodpDoljpost`,`PodpDoljpostRod`,`PodpOsnovan`,`PodpOsnovanRod`,`URLSite`,`Phone`,`Email`,`KontTehFio`,`KontTehEmail`,`KontTehPhone`,`KontFinansFio`,`KontFinansEmail`,`KontFinansPhone`,`RSchet`,`KSchet`,`BankName`,`BikBank`,`PaaswordApi`,`IpAccesApi`,`IsMfo`,`SchetTcb`,`LoginTkbAft`,`KeyTkbAft`,`LoginTkbEcom`,`KeyTkbEcom`,`IsBlocked`,`IsDeleted`) values (1,'ПРОЦЕССИНГОВАЯ КОМПАНИЯ БЫСТРЫХ ПЛАТЕЖЕЙ','','','','','','',1571726560,'','','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0),(2,'МФО ЦВЗ','ЦВЗ','','','','','',1571748744,'','','','','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70fCK0R5G8bPZ21PMw',NULL,1,NULL,'P1479100766ID','vHSsaMFF07bDGRSb608E7Wd0unCDQAe7ksK30ib2v8JyEYP6pemWw28JE16WibZz2dtogYkXYgi8oOwEGEpLprLrtby7koTuijFBFB0z3x6qU8v0FCpOVpjLBb4fzmMLwY0di48fOZR0tvGtQHCS8fH3838DFV8RVw24irRLCi85GsrfEMy1T2Mrq5eo4FK2Z8f6CLkzZ1qZfLwQM372wh71UMOmmDQ6JffGmuM3A8b1NVkOJyMaGQGSbom058nw',NULL,NULL,0,0),(3,'МФО CTY','ООО МКК Универсального Финансирования','','','','','',1572600773,'','','','','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'45Qxi96x32f3z91L6g',NULL,1,NULL,'P1539100788ID','3JMOgOUbdYnZOgCnMxry5MgOoZqBRZ31d66u6LdeOsp5KAEXFK0YKMJsB7zqystn3vWRjhpbumUOwkeWuB5h8frAyP18kWQv7cboOXOxvZDy144q3N45wmnXevsDqp0GEyPuiZiFWHWjL1HCULfG1U7WYojsFjhf763DpKhdDziXzdmmXYTOjtPTz2F4PZaMARkO7eojDbdBMkwUb7EQAD4PsjdwdnxNyFxS2HnSLKjhpnhpFV2Rvum6VEvYa0gr','P1536100787ID','wYzLsHivQ4zdNrz8teTf4akO1qWFSrvvBBRVvL3SnRF5VRSde3MSCpcwOUScVNNyKdMkKOOSja1oDp2jGSAYPN2mzuhL106KdhvSfGDAq2HBwX2z0HEcmYT6kAUpGcZtdsjv2jeapaHVfBZLBSTuw3ypyxHOWo3ndoxdNGFRCEXmq61SKiWYtE5i336FMznafvR0dV64mc00gm8AEYeNBf3JspjTJaecrWf3pbPYk0MqNfbR4GaXvKJ8AiJXMowm',0,0);

UNLOCK TABLES;

/*Table structure for table `partner_bank_rekviz` */

DROP TABLE IF EXISTS `partner_bank_rekviz`;

CREATE TABLE `partner_bank_rekviz` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPartner` int(10) unsigned NOT NULL COMMENT 'id partner',
  `NamePoluchat` varchar(200) DEFAULT NULL,
  `INNPolushat` varchar(20) DEFAULT NULL,
  `KPPPoluchat` varchar(20) DEFAULT NULL,
  `KorShetPolushat` varchar(40) DEFAULT NULL,
  `RaschShetPolushat` varchar(40) DEFAULT NULL,
  `NameBankPoluchat` varchar(150) DEFAULT NULL,
  `SityBankPoluchat` varchar(80) DEFAULT NULL,
  `BIKPoluchat` varchar(20) DEFAULT NULL,
  `PokazKBK` varchar(40) DEFAULT NULL,
  `OKATO` varchar(20) DEFAULT NULL,
  `NaznachenPlatez` varchar(300) DEFAULT NULL,
  `SummReestrAutoOplat` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'сумма к перечислению (для предоплаты), 0 - долг оплатить',
  `MinSummReestrToOplat` int(10) NOT NULL DEFAULT '0' COMMENT 'сумма долга после которой оплату производить',
  `MaxIntervalOplat` int(10) NOT NULL DEFAULT '0' COMMENT 'максимальный срок между перечислениями в днях',
  `IsDecVoznagPerecisl` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - удерживать вознаграждение при перечислении',
  `ExportBankType` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'банк для выгрузки',
  `DateLastExport` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'дата последней оплаты',
  `BalanceSumm` int(11) NOT NULL DEFAULT '0' COMMENT 'сумма долга перед партнером',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `partner_bank_rekviz` */

LOCK TABLES `partner_bank_rekviz` WRITE;

UNLOCK TABLES;

/*Table structure for table `partner_dogovor` */

DROP TABLE IF EXISTS `partner_dogovor`;

CREATE TABLE `partner_dogovor` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPartner` int(10) unsigned NOT NULL COMMENT 'id partner',
  `NameMagazin` varchar(100) DEFAULT NULL COMMENT 'naimenovane magazina',
  `TypeMagazin` int(11) DEFAULT NULL COMMENT 'tip: 0 - inet 1 - torgov 2 - mobile',
  `NumDogovor` varchar(20) DEFAULT NULL COMMENT 'nomer',
  `DateDogovor` varchar(20) DEFAULT NULL COMMENT 'data',
  `PodpisantFull` varchar(100) DEFAULT NULL COMMENT 'podpisant polnostyu',
  `PodpisantShort` varchar(50) DEFAULT NULL COMMENT 'podpisant kratko',
  `PodpDoljpost` varchar(50) DEFAULT NULL COMMENT 'doljnost',
  `PodpOsnovan` varchar(100) DEFAULT NULL COMMENT 'osnodanie',
  `Adres` varchar(1000) DEFAULT NULL COMMENT 'adres ili url',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udalen',
  PRIMARY KEY (`ID`),
  KEY `IdPartner` (`IdPartner`,`IsDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `partner_dogovor` */

LOCK TABLES `partner_dogovor` WRITE;

UNLOCK TABLES;

/*Table structure for table `partner_sumorder` */

DROP TABLE IF EXISTS `partner_sumorder`;

CREATE TABLE `partner_sumorder` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdPartner` int(10) unsigned NOT NULL COMMENT 'id partner',
  `IdRekviz` int(10) unsigned NOT NULL COMMENT 'id partner_bank_rekviz',
  `Comment` varchar(250) DEFAULT NULL COMMENT 'info',
  `Summ` int(11) NOT NULL DEFAULT '0' COMMENT 'summa',
  `DateOp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data',
  `TypeOrder` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip 0 - oplata reestr 1 - sozdanie reestra 3 - otmena oplaty',
  `SummAfter` int(11) NOT NULL DEFAULT '0' COMMENT 'summa balansa posle operacii',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `partner_sumorder` */

LOCK TABLES `partner_sumorder` WRITE;

UNLOCK TABLES;

/*Table structure for table `partner_users` */

DROP TABLE IF EXISTS `partner_users`;

CREATE TABLE `partner_users` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Login` varchar(20) NOT NULL COMMENT 'login',
  `Password` varchar(100) NOT NULL COMMENT 'pw sha2',
  `IsAdmin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - admin 0 - partner',
  `RoleUser` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - user 1 - partner admin',
  `IdPartner` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id partner',
  `FIO` varchar(100) DEFAULT NULL COMMENT 'fio',
  `Email` varchar(50) DEFAULT NULL COMMENT 'email',
  `Doljnost` varchar(100) DEFAULT NULL COMMENT 'doljnost',
  `IsActive` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0 - off 1 - on',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Login` (`Login`),
  KEY `IsAdmin` (`IsAdmin`),
  KEY `IdPartner` (`IdPartner`,`IsDeleted`,`IsActive`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `partner_users` */

LOCK TABLES `partner_users` WRITE;

insert  into `partner_users`(`ID`,`Login`,`Password`,`IsAdmin`,`RoleUser`,`IdPartner`,`FIO`,`Email`,`Doljnost`,`IsActive`,`IsDeleted`) values (1,'admin','684937767fdc1b81e277a0a2570d806ac1e6157441c8bfbf9d2da90f85e0b4fb',1,0,0,'admin',NULL,NULL,1,0),(2,'mfocvz','e85aeb8fe130ef6102cb974bb375e3319a548f41cf802e69e076e4c08fdbb958',0,1,2,'mfocvz','','',1,0),(3,'mfocty','fd5a45e232ce557422190cb4c62446c65e732263c18bd7e1780d8d3e84734409',0,1,3,'МФО CTY','','',1,0);

UNLOCK TABLES;

/*Table structure for table `pay_bonus` */

DROP TABLE IF EXISTS `pay_bonus`;

CREATE TABLE `pay_bonus` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id user',
  `IdPay` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id pay_schet',
  `Summ` int(11) NOT NULL DEFAULT '0' COMMENT 'summa',
  `TypeOp` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 - popolnen 1 - spisan',
  `DateOp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data',
  `Comment` varchar(250) DEFAULT '' COMMENT 'kommentraiii',
  `BonusAfter` int(11) NOT NULL DEFAULT '0' COMMENT 'summa posle operacii',
  PRIMARY KEY (`ID`),
  KEY `IsUser` (`IdUser`,`TypeOp`,`DateOp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `pay_bonus` */

LOCK TABLES `pay_bonus` WRITE;

UNLOCK TABLES;

/*Table structure for table `pay_schet` */

DROP TABLE IF EXISTS `pay_schet`;

CREATE TABLE `pay_schet` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id user',
  `IdKard` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id kard, esli privaizanoi kartoi oplata',
  `IdUsluga` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id usluga',
  `IdShablon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id shablon',
  `IdOrder` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id order_pay',
  `IdOrg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'custom id partner',
  `Extid` varchar(40) DEFAULT NULL COMMENT 'custom partner vneshnii id',
  `IdGroupOplat` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'gruppovaya oplata po pay_schgroup',
  `Period` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'period reestra',
  `Schetcheks` varchar(100) DEFAULT NULL COMMENT 'pokazania schetchikov. razdelenie |',
  `IdQrProv` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'uslugatovar.ProfitIdProvider, esli bez shablona oplata',
  `QrParams` varchar(500) DEFAULT NULL COMMENT 'rekvizity dlia oplaty',
  `SummPay` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa plateja v kopeikah',
  `ComissSumm` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa komissii',
  `Status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'status: 0 - sozdan, 1 - oplachen, 2 - oshibka oplaty',
  `ErrorInfo` varchar(250) DEFAULT NULL COMMENT 'soobchenie oshibki',
  `DateCreate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'date create',
  `DateOplat` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'date oplata',
  `DateLastUpdate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data poslednego obnovlenia zapisi',
  `PayType` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip oplaty: 0 - bankovskaya karta, 1 - qiwi, 2 - mail.ru',
  `TimeElapsed` int(10) unsigned NOT NULL DEFAULT '1800' COMMENT 'srok oplaty v sec',
  `ExtBillNumber` varchar(50) DEFAULT NULL COMMENT 'nomer transakcii uniteller',
  `ExtKeyAcces` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'kod scheta uniteller',
  `ApprovalCode` varchar(20) DEFAULT NULL COMMENT 'kod avtorizacii',
  `RRN` varchar(20) DEFAULT NULL COMMENT 'nomer RRN',
  `CardNum` varchar(30) DEFAULT NULL COMMENT 'nomer karty',
  `CardType` varchar(30) DEFAULT NULL COMMENT 'tip karty',
  `BankName` varchar(100) DEFAULT NULL COMMENT 'bank karty',
  `IPAddressUser` varchar(30) DEFAULT NULL COMMENT 'ip adres platelshika',
  `CountryUser` varchar(100) DEFAULT NULL COMMENT 'strana platelshika',
  `CityUser` varchar(100) DEFAULT NULL COMMENT 'gorod platelshika',
  `UserClickPay` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 - ne klikal oplatu 1 - klikal oplatu',
  `CountSendOK` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'kollichestvo poslanyh zaprosov v magazin ob uspeshnoi oplate',
  `SendKvitMail` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'otpravit kvitanciuu ob oplate na pochtu',
  `IdAgent` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id agent site',
  `GisjkhGuid` varchar(50) DEFAULT NULL COMMENT 'guid gis jkh',
  `TypeWidget` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - web communal 1 - mobile 2 - shop 3 - qr schet',
  `Bank` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'bank: 0 - rsb 1 - rossia',
  `IsAutoPay` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - avtoplatej',
  `UrlFormPay` varchar(2000) DEFAULT NULL COMMENT 'url dlia perehoda k oplate',
  `UserUrlInform` varchar(1000) DEFAULT NULL COMMENT 'url dlia kollbeka pletelshiky',
  `UserKeyInform` varchar(50) DEFAULT NULL COMMENT 'kluch dlia kollbeka pletelshiky',
  `SuccessUrl` varchar(1000) DEFAULT NULL COMMENT 'url dlia vozvrata pri uspehe',
  `FailedUrl` varchar(1000) DEFAULT NULL COMMENT 'url dlia vozvrata pri otkaze',
  PRIMARY KEY (`ID`),
  KEY `Status` (`Status`,`DateOplat`),
  KEY `ExtBillNumber` (`ExtBillNumber`),
  KEY `IdOrg` (`IdOrg`,`Extid`,`IdUsluga`,`DateCreate`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `pay_schet` */

LOCK TABLES `pay_schet` WRITE;

UNLOCK TABLES;

/*Table structure for table `pay_schgroup` */

DROP TABLE IF EXISTS `pay_schgroup`;

CREATE TABLE `pay_schgroup` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DateAdd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data cozdania',
  `DateOplat` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data oplaty',
  `SummPays` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'summa platejeii',
  `ComisPays` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'komissia po platejam',
  `CountPays` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'chislo platejei',
  `Status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - novyii 1 - oplachen 2 - otmenen',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `pay_schgroup` */

LOCK TABLES `pay_schgroup` WRITE;

UNLOCK TABLES;

/*Table structure for table `qr_group` */

DROP TABLE IF EXISTS `qr_group`;

CREATE TABLE `qr_group` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NameGroup` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `qr_group` */

LOCK TABLES `qr_group` WRITE;

UNLOCK TABLES;

/*Table structure for table `queue` */

DROP TABLE IF EXISTS `queue`;

CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL,
  `job` blob NOT NULL,
  `pushed_at` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `reserved_at` int(11) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `done_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`),
  KEY `reserved_at` (`reserved_at`),
  KEY `priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `queue` */

LOCK TABLES `queue` WRITE;

UNLOCK TABLES;

/*Table structure for table `reestr_bankpl` */

DROP TABLE IF EXISTS `reestr_bankpl`;

CREATE TABLE `reestr_bankpl` (
  `IdBankpl` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DatePayd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '0 - ne oplachen / > 0 - data oplaty',
  `DateCreate` int(10) unsigned NOT NULL DEFAULT '0',
  `Summ` int(11) NOT NULL DEFAULT '0',
  `FilePl` varchar(40) NOT NULL DEFAULT '',
  `CountPls` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IdBankpl`),
  KEY `IdProv` (`DatePayd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='платежные поручения в банк';

/*Data for the table `reestr_bankpl` */

LOCK TABLES `reestr_bankpl` WRITE;

UNLOCK TABLES;

/*Table structure for table `send_sms` */

DROP TABLE IF EXISTS `send_sms`;

CREATE TABLE `send_sms` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DateIn` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data sozdania',
  `DateSend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'data otpravki',
  `NumPhone` varchar(12) NOT NULL DEFAULT '' COMMENT 'nomer bez 8',
  `StateSend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - v obrabotke 1 - otpravleno 2 - oshibka',
  `MsgText` varchar(600) NOT NULL DEFAULT '' COMMENT 'tekst',
  PRIMARY KEY (`ID`),
  KEY `StateSend` (`StateSend`),
  KEY `DateIn` (`DateIn`,`StateSend`),
  KEY `DateSend` (`DateSend`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COMMENT='Рассылка SMS оповещений жильцам';

/*Data for the table `send_sms` */

LOCK TABLES `send_sms` WRITE;

UNLOCK TABLES;

/*Table structure for table `session` */

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `id` char(40) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `session` */

LOCK TABLES `session` WRITE;

insert  into `session`(`id`,`expire`,`data`) values ('49ap1hjfl7n5l8rh7arp7nrab1',1571794907,'__flash|a:0:{}__id|s:6:\"mfocvz\";'),('bln701e00mjmekq359ka0h4704',1571795136,'__flash|a:0:{}'),('l29ii7lk0ns05ab6cc4q207sa6',1572982214,'__flash|a:0:{}'),('silok8jk0nao7fh470aeq369s0',1571774923,'__flash|a:0:{}__id|s:5:\"admin\";');

UNLOCK TABLES;

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Login` varchar(50) DEFAULT NULL COMMENT 'login',
  `Password` varchar(100) DEFAULT NULL COMMENT 'parol dostypa sha',
  `Pinpay` varchar(100) DEFAULT NULL COMMENT 'pin plateja sha',
  `BonusBalance` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'bonusy',
  `ExtOrg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'ext partner',
  `ExtCustomerIDP` varchar(128) DEFAULT NULL COMMENT 'vneshniii id klienta 64 simvola',
  `Fam` varchar(100) DEFAULT NULL COMMENT 'familia',
  `Name` varchar(100) DEFAULT NULL COMMENT 'imia',
  `Otch` varchar(100) DEFAULT NULL COMMENT 'otchestvo',
  `Inn` varchar(20) DEFAULT NULL COMMENT 'inn',
  `Snils` varchar(40) DEFAULT NULL COMMENT 'snils',
  `Email` varchar(100) DEFAULT NULL COMMENT 'pochta / mobile identificator',
  `TempEmail` varchar(100) DEFAULT NULL COMMENT 'vremennyii email',
  `VerificCode` varchar(128) DEFAULT NULL COMMENT 'kod podtverjdenia',
  `Phone` varchar(20) DEFAULT NULL COMMENT 'telefon',
  `DateRegister` int(10) unsigned NOT NULL COMMENT 'data registracii',
  `IMEI` varchar(36) NOT NULL DEFAULT '0' COMMENT 'IMEI nomer telefona / UUID',
  `UserDeviceType` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip ustroistva: 0 - n/a 1 - web 2 - android 3 - iphone',
  `SendUvedolmen` tinyint(1) unsigned DEFAULT '1' COMMENT 'Poluchat uvedomleniia',
  `SendPush` tinyint(1) unsigned DEFAULT '1' COMMENT 'Ispolzovat PUSH',
  `SendInSchets` tinyint(1) unsigned DEFAULT '1' COMMENT 'O postupivshikh schetakh',
  `SendInfoOplata` tinyint(1) unsigned DEFAULT '1' COMMENT 'Ob oplate',
  `SendReclPartner` tinyint(1) unsigned DEFAULT '1' COMMENT 'Reclamnye soobshcheniia partnerov',
  `IsBonusCopy` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 - nakaplivat bonusy',
  `IsUsePassw` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - ispolzovat parol dlia vhoda',
  `IsUsePinpay` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - ispolzovat pin dlia oplaty',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - activen 1 - udalen',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`,`IMEI`),
  UNIQUE KEY `Login` (`Login`,`ExtOrg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

LOCK TABLES `user` WRITE;

UNLOCK TABLES;

/*Table structure for table `user_address` */

DROP TABLE IF EXISTS `user_address`;

CREATE TABLE `user_address` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `Name` varchar(150) DEFAULT NULL COMMENT 'naimenovanie',
  `CoordX` double unsigned NOT NULL DEFAULT '0' COMMENT 'position X',
  `CoordY` double unsigned NOT NULL DEFAULT '0' COMMENT 'position Y',
  `TypeRegion` varchar(30) DEFAULT NULL COMMENT 'adres',
  `Region` varchar(150) DEFAULT NULL,
  `Raion` varchar(150) DEFAULT NULL,
  `TypeCity` varchar(30) DEFAULT NULL,
  `City` varchar(150) DEFAULT NULL,
  `TypeStreet` varchar(30) DEFAULT NULL,
  `Street` varchar(150) DEFAULT NULL,
  `House` varchar(30) DEFAULT NULL,
  `Copr` varchar(30) DEFAULT NULL,
  `Stroen` varchar(30) DEFAULT NULL,
  `Podiezd` varchar(30) DEFAULT NULL,
  `Etaj` varchar(30) DEFAULT NULL,
  `Flat` varchar(30) DEFAULT NULL,
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`,`IsDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_address` */

LOCK TABLES `user_address` WRITE;

UNLOCK TABLES;

/*Table structure for table `user_car` */

DROP TABLE IF EXISTS `user_car`;

CREATE TABLE `user_car` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `CarName` varchar(100) DEFAULT NULL COMMENT 'carname',
  `Number` varbinary(10) DEFAULT NULL COMMENT 'gos number car',
  `Vud` varchar(10) DEFAULT NULL COMMENT 'vodit udostoverenie',
  `Sts` varchar(10) DEFAULT NULL COMMENT 'cvid o registr auto',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`,`IsDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_car` */

LOCK TABLES `user_car` WRITE;

UNLOCK TABLES;

/*Table structure for table `user_favor_uslug` */

DROP TABLE IF EXISTS `user_favor_uslug`;

CREATE TABLE `user_favor_uslug` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id user',
  `IdUslug` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id uslugatovar',
  `Name` varchar(150) DEFAULT NULL COMMENT 'naimenovanie',
  `Rekviz` varchar(1500) DEFAULT NULL COMMENT 'rekvizity',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`,`IsDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_favor_uslug` */

LOCK TABLES `user_favor_uslug` WRITE;

UNLOCK TABLES;

/*Table structure for table `user_identification` */

DROP TABLE IF EXISTS `user_identification`;

CREATE TABLE `user_identification` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL,
  `IdOrg` int(10) NOT NULL,
  `TransNum` int(10) NOT NULL DEFAULT '0',
  `DateOp` int(10) NOT NULL DEFAULT '0',
  `Name` varchar(50) DEFAULT NULL,
  `Fam` varchar(50) DEFAULT NULL,
  `Otch` varchar(50) DEFAULT NULL,
  `BirthDay` bigint(20) NOT NULL DEFAULT '0',
  `Inn` varchar(20) DEFAULT NULL,
  `Snils` varchar(50) DEFAULT NULL,
  `PaspSer` varchar(10) DEFAULT NULL,
  `PaspNum` varchar(10) DEFAULT NULL,
  `PaspPodr` varchar(10) DEFAULT NULL,
  `PaspDate` int(11) NOT NULL DEFAULT '0',
  `PaspVidan` varchar(200) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `PhoneCode` varchar(20) DEFAULT NULL,
  `StateOp` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 - создан 1 - подтвержден 2 - отклонен',
  `ErrorMessage` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`,`IdUser`,`IdOrg`,`TransNum`,`DateOp`,`BirthDay`,`PaspDate`,`StateOp`),
  KEY `IdUser` (`IdUser`,`StateOp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_identification` */

LOCK TABLES `user_identification` WRITE;

UNLOCK TABLES;

/*Table structure for table `user_quest` */

DROP TABLE IF EXISTS `user_quest`;

CREATE TABLE `user_quest` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdUser` int(10) unsigned NOT NULL COMMENT 'id user',
  `Quest` varchar(200) DEFAULT NULL COMMENT 'tekst voporsa',
  `Answer` varchar(100) DEFAULT NULL COMMENT 'tekst otveta',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - udaleno',
  PRIMARY KEY (`ID`),
  KEY `IdUser` (`IdUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_quest` */

LOCK TABLES `user_quest` WRITE;

UNLOCK TABLES;

/*Table structure for table `usluga_reestr_group` */

DROP TABLE IF EXISTS `usluga_reestr_group`;

CREATE TABLE `usluga_reestr_group` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IdMainUsluga` int(10) unsigned NOT NULL COMMENT 'id glavnoi uslugi',
  `IdUsluga` int(10) unsigned NOT NULL COMMENT 'id uslugi',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IdMainUsluga` (`IdMainUsluga`,`IdUsluga`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `usluga_reestr_group` */

LOCK TABLES `usluga_reestr_group` WRITE;

UNLOCK TABLES;

/*Table structure for table `uslugatovar` */

DROP TABLE IF EXISTS `uslugatovar`;

CREATE TABLE `uslugatovar` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IDPartner` int(10) unsigned NOT NULL COMMENT 'id partner',
  `IdMagazin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id partner_dogovor',
  `IsCustom` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - obshaia 1 - widget order 2 - merchant 10 - mfo in 11 - mfo out',
  `CustomData` text COMMENT 'danuue customnogo',
  `ExtReestrIDUsluga` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id uslugi v reestrah',
  `NameUsluga` varchar(200) DEFAULT NULL COMMENT 'naimenovanie uslugi',
  `InfoUsluga` varchar(500) DEFAULT NULL COMMENT 'opisanie uslugi',
  `SitePoint` varchar(50) DEFAULT NULL COMMENT 'sait ustanovki',
  `PatternFind` varchar(250) DEFAULT NULL COMMENT 'pattern dlia poiska provaidera po qr-cody',
  `ProfitExportFormat` varchar(250) DEFAULT NULL COMMENT 'format eksporta: LS, PERIOD, FIO, ADDRESS',
  `QrcodeExportFormat` varchar(500) DEFAULT NULL COMMENT 'qr code format eksporta: LS, PERIOD, FIO, ADDRESS',
  `SchetchikFormat` varchar(250) DEFAULT NULL COMMENT 'schetchiki uslugi, razdelenie |, format - regexp',
  `SchetchikNames` varchar(250) DEFAULT NULL COMMENT 'naimenovanie schetchikov uslugi, razdelenie |',
  `SchetchikIzm` varchar(250) DEFAULT NULL COMMENT 'edinicy izmerenia schetchikov uslugi, razdelenie |',
  `PartnerSiteReferer` varchar(250) DEFAULT NULL COMMENT 'referer dlia freima saita partnera po usluge',
  `PcComission` double unsigned DEFAULT '0' COMMENT 'procent komissii',
  `MinsumComiss` double unsigned DEFAULT '0' COMMENT 'minimalnaya komissiia v rub',
  `Information` varchar(500) DEFAULT NULL COMMENT 'informacia po usluge',
  `Group` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id qr_group',
  `Region` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id uslugi_regions',
  `LogoProv` varchar(100) DEFAULT NULL COMMENT 'logotip',
  `MinSumm` int(10) unsigned NOT NULL DEFAULT '100' COMMENT 'minimalnaya symma plateja',
  `MaxSumm` int(10) unsigned NOT NULL DEFAULT '1500000' COMMENT 'maksimalnaya symma plateja',
  `Labels` varchar(500) DEFAULT NULL COMMENT 'podpis vvoda - |',
  `Comments` varchar(500) DEFAULT NULL COMMENT 'kommentarii vvoda - |',
  `Example` varchar(500) DEFAULT NULL COMMENT 'primer vvoda - |',
  `Mask` varchar(500) DEFAULT NULL COMMENT 'maska vvoda - |',
  `Regex` varchar(300) DEFAULT NULL COMMENT 'regularki - |||',
  `LabelsInfo` varchar(300) DEFAULT NULL COMMENT 'podpis info - |',
  `CommentsInfo` varchar(300) DEFAULT NULL COMMENT 'kommentarii info - |',
  `ExampleInfo` varchar(100) DEFAULT NULL COMMENT 'primer info - |',
  `MaskInfo` varchar(100) DEFAULT NULL COMMENT 'maska info - |',
  `RegexInfo` varchar(100) DEFAULT NULL COMMENT 'regularki info - |||',
  `ProvVoznagPC` double unsigned NOT NULL DEFAULT '0' COMMENT 'voznag %',
  `ProvVoznagMin` double unsigned NOT NULL DEFAULT '0',
  `ProvComisPC` double unsigned NOT NULL DEFAULT '0' COMMENT 'prov komis %',
  `ProvComisMin` double unsigned NOT NULL DEFAULT '0',
  `TypeExport` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip eksporta plateja: 0 - v teleport 1 - po banky po reestram 2 - online',
  `ProfitIdProvider` int(10) unsigned DEFAULT NULL COMMENT 'id systemgorod.providers',
  `TypeReestr` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'tip reestra: 0 - teleport 1 - sber full 2 - sber gv 3 - sber hv 4 - kes 5 - ds kirov 6 - fkr43 7 - gaz 8 - sber new',
  `EmailReestr` varchar(100) DEFAULT NULL COMMENT 'email dlia reestra',
  `KodPoluchat` varchar(20) DEFAULT NULL COMMENT 'kod poluchatela v resstre',
  `ReestrNameFormat` varchar(100) DEFAULT NULL COMMENT 'format imeni reestra',
  `GroupReestrMain` tinyint(10) unsigned NOT NULL DEFAULT '0' COMMENT '1 - gruppirovka poiska po reestram',
  `UrlInform` varchar(500) DEFAULT NULL COMMENT 'url dlia informacii o plateje',
  `KeyInform` varchar(20) DEFAULT NULL COMMENT 'kod informirovania',
  `UrlReturn` varchar(500) DEFAULT NULL COMMENT 'url dlia vozvrata v magazin',
  `UrlReturnFail` varchar(500) DEFAULT NULL COMMENT 'url dlia vozvrata v magazin pri oshibke',
  `SupportInfo` varchar(100) DEFAULT NULL COMMENT 'email slujby podderjki magazina',
  `IdBankRekviz` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'id partner_bank_rekviz',
  `SendToGisjkh` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - otpravliat v gis jkh',
  `EnabledStatus` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - novaya 1 - activnaya 2 - zablokirovana',
  `EmailShablon` text COMMENT 'tekst shablona uvedmlenia',
  `ColorWdtMain` varchar(10) DEFAULT NULL COMMENT 'ocnovnoi cvet v vidgete',
  `ColorWdtActive` varchar(10) DEFAULT NULL COMMENT 'cvet vydelenia v vidgete',
  `IsKommunal` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 - jkh 0 - ecomm',
  `HideFromList` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 - skryt iz spiska',
  `IsDeleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 - activen 1 - udalen',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ProfitIdProvider` (`ProfitIdProvider`),
  KEY `IDPartner` (`IDPartner`,`IsCustom`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `uslugatovar` */

LOCK TABLES `uslugatovar` WRITE;

insert  into `uslugatovar`(`ID`,`IDPartner`,`IdMagazin`,`IsCustom`,`CustomData`,`ExtReestrIDUsluga`,`NameUsluga`,`InfoUsluga`,`SitePoint`,`PatternFind`,`ProfitExportFormat`,`QrcodeExportFormat`,`SchetchikFormat`,`SchetchikNames`,`SchetchikIzm`,`PartnerSiteReferer`,`PcComission`,`MinsumComiss`,`Information`,`Group`,`Region`,`LogoProv`,`MinSumm`,`MaxSumm`,`Labels`,`Comments`,`Example`,`Mask`,`Regex`,`LabelsInfo`,`CommentsInfo`,`ExampleInfo`,`MaskInfo`,`RegexInfo`,`ProvVoznagPC`,`ProvVoznagMin`,`ProvComisPC`,`ProvComisMin`,`TypeExport`,`ProfitIdProvider`,`TypeReestr`,`EmailReestr`,`KodPoluchat`,`ReestrNameFormat`,`GroupReestrMain`,`UrlInform`,`KeyInform`,`UrlReturn`,`UrlReturnFail`,`SupportInfo`,`IdBankRekviz`,`SendToGisjkh`,`EnabledStatus`,`EmailShablon`,`ColorWdtMain`,`ColorWdtActive`,`IsKommunal`,`HideFromList`,`IsDeleted`) values (1,1,0,0,NULL,0,'Регистрация карты','',NULL,'','LS','','','','','',0,0,'',888,2,'com_kvpl.png',100,1500000,'Лицевой счет','','','9999999999','\\d{1,9}',NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,10520,0,'',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,1,0),(100,2,0,11,NULL,0,'Выдача займа на счет.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(101,2,0,13,NULL,0,'Выдача займа на карту.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(102,2,0,10,NULL,0,'Погашение займа AFT.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1.2,45,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(103,2,0,12,NULL,0,'Автоплатеж по займу AFT.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1.2,45,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(104,2,0,14,NULL,0,'Погашение займа ECOM.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2.2,0.01,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(105,2,0,16,NULL,0,'Автоплатеж по займу ECOM.МФО ЦВЗ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2.2,0.6,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(106,3,0,11,NULL,0,'Выдача займа на счет.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(107,3,0,13,NULL,0,'Выдача займа на карту.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(108,3,0,10,NULL,0,'Погашение займа AFT.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1.2,45,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(109,3,0,12,NULL,0,'Автоплатеж по займу AFT.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1.2,45,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(110,3,0,14,NULL,0,'Погашение займа ECOM.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2.2,0.01,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0),(111,3,0,16,NULL,0,'Автоплатеж по займу ECOM.МФО CTY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2.2,0.6,NULL,0,0,NULL,100,1500000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,1,0,0);

UNLOCK TABLES;

/*Table structure for table `uslugi_regions` */

DROP TABLE IF EXISTS `uslugi_regions`;

CREATE TABLE `uslugi_regions` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NameRegion` varchar(100) NOT NULL COMMENT 'region uslugi',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `uslugi_regions` */

LOCK TABLES `uslugi_regions` WRITE;

UNLOCK TABLES;

/*Table structure for table `usluglinks` */

DROP TABLE IF EXISTS `usluglinks`;

CREATE TABLE `usluglinks` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'sviaz uslug',
  `IdUsl1` int(11) DEFAULT NULL COMMENT 'id uslugatovar 1',
  `IdUsl2` int(11) DEFAULT NULL COMMENT 'id uslugatovar 2',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `usluglinks` */

LOCK TABLES `usluglinks` WRITE;

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
